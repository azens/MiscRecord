<title>WebGL simplest</title>
<canvas id="canvas" style="border:3px solid cyan;" width="400" height="400">
</canvas>
<script>
var webgl=canvas.getContext("experimental-webgl");
var vs,fs,vs_s,fs_s;
var yanse=function(vs_s,fs_s,n){
var program=webgl.createProgram();
vs=webgl.createShader(webgl.VERTEX_SHADER);
fs=webgl.createShader(webgl.FRAGMENT_SHADER);
webgl.shaderSource(vs,vs_s);webgl.shaderSource(fs,fs_s);
webgl.compileShader(vs);webgl.compileShader(fs);
webgl.attachShader(program,vs);webgl.attachShader(program,fs);
webgl.linkProgram(program);webgl.useProgram(program);
/////////////////////////////////////
dat=new Array(n*4);dat[0]=-3.14;
for(i=1;i<n;i++)
dat[i*4]=dat[(i-1)*4]+2*Math.PI/n,
dat[i*4+1]=Math.sin(dat[i*4]),
dat[i*4+2]=0,dat[i*4+3]=1;
for(i=1;i<n;i++)
dat[i*4]/=4;
/////////////////////////////////////
dat=new Float32Array(dat);
var buf=webgl.createBuffer();
webgl.bindBuffer(webgl.ARRAY_BUFFER,buf);
webgl.bufferData(webgl.ARRAY_BUFFER,dat,webgl.STATIC_DRAW);
var p=webgl.getAttribLocation(program,"p");
webgl.enableVertexAttribArray(p);
webgl.vertexAttribPointer(p,4,webgl.FLOAT,false,0,0);
}
//������
n1=628;
vs_s="attribute vec4 p;void main(){gl_Position=p;}";
fs_s="void main(){gl_FragColor=vec4(1.0,0.0,0.0,1.0);}";
yanse(vs_s,fs_s,n1);
webgl.drawArrays(webgl.LINE_STRIP,0,n1);
//���Ƶ�
n2=62;
vs_s="attribute vec4 p;void main(){gl_Position=p;gl_PointSize=5.0;}";
fs_s="void main(){gl_FragColor=vec4(0.0,1.0,0.0,1.0);}";
yanse(vs_s,fs_s,n2);
webgl.drawArrays(webgl.POINTS,0,n2);
</script>